import angular from 'angular';
import 'angular-ui-router';

angular.module('home-app', ['ui.router']);
